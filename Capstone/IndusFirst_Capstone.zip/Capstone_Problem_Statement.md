# Take-Home Mini-Project — Customer Email Triage Agent for Indus First Bank

**Program:** eClerx GenAI Engineer Training, Cohort 1
**Instructor:** Prashant Sahu
**Issued:** End of Day 8
**Due:** Start of Day 9 (after the 4-day break)
**Time budget:** 18-25 hours over 4 days
**Submission:** one notebook + one architecture diagram + a 1-page write-up, zipped

---

## 1. Background — what your client just told you in the kickoff

You are joining **Indus First Bank** as a GenAI Engineer for an 8-week pilot. Indus First is a synthetic mid-sized Indian retail bank used in this assignment as a stand-in for the kind of client you'll deploy into. Treat it as real — every detail below is taken from real Indian-banking workflows.

> *"We're at 12 % SLA breach on inbound customer email. Our 25 Tier-1 agents in Mumbai handle ~800 emails a day, and we're losing the easy ones in the queue while they fight to get the hard ones out the door. We don't want to fire anyone. We want to give them an agent that handles the mechanical parts so they can spend their time on the cases that actually need a human."*
>
> — Anjali Menon, VP Customer Operations, Indus First Bank

Five things a Tier-1 agent does on every inbound email today:

| Step | Action | Mechanical or judgement? |
|---|---|---|
| 1 | Read the email and decide which of 5 categories it falls into | Mechanical |
| 2 | Look up the relevant bank policy in a 600-page PDF intranet | Mechanical |
| 3 | Draft a reply using a templated outline | Mechanical |
| 4 | Sanitise the reply — strip any PII the customer pasted in | Mechanical (and a regulatory must-do) |
| 5 | Decide: send myself, or escalate to Tier-2? | **Judgement — keep human** |

Your scope is steps **1-4**. Step 5 stays human, but your agent must give the human all the information they need to decide in under 30 seconds.

## 2. Your role and the deliverable shape

You are the only engineer on this. You own:

- **Design** — pick the agent shape, the routing logic, the PII-defence model
- **Build** — wire it together using LangGraph + AWS services
- **Evaluate** — measure it on a 20-email test set the bank gave you (provided in `emails/`)
- **Defend** — write a 1-page brief justifying every architectural choice

You do **not** own:
- Sending the actual emails (out of scope — your output is a structured `TriageResult`)
- Building the human-review UI (out of scope — your output is a queue record)
- Production deployment (Day 9-10 of the program will cover that — write your code so it can be deployed later, but don't deploy it now)

## 3. The problem statement

For each inbound email in the `emails/` folder, your agent must produce a `TriageResult` record containing:

```python
class TriageResult(BaseModel):
    email_id: str                          # the input email's id
    category: Literal["loan", "account", "fraud", "complaint", "info", "unsupported"]
    confidence: float                      # 0.0 - 1.0, your model's self-assessed confidence
    pii_redacted_input: str                # the email body with PII replaced by [<TYPE>_REDACTED]
    pii_entities_caught: list[str]         # which PII types were found, e.g. ["PAN", "Aadhaar"]
    drafted_reply: str | None              # your agent's proposed reply (None for unsupported)
    citations: list[Citation]              # which policy docs grounded the reply
    output_pii_check: Literal["PASS", "BLOCK"]  # did the Bedrock Guardrail accept the reply?
    handoff: Literal["READY_TO_SEND", "HUMAN_REVIEW"]
    handoff_reason: str | None             # one-line explanation, only set if HUMAN_REVIEW
    reasoning_log: list[str]               # ordered list of node decisions for audit
```

`Citation`:
```python
class Citation(BaseModel):
    doc_id: str        # e.g. "pl_underwriting_policy_2024"
    section: str       # e.g. "4.2"
    page: int | None   # if known
```

## 4. Functional requirements

Your agent must:

**FR-1 — Classify** every email into exactly one of 6 categories. Use a LangGraph router node with conditional edges into per-category specialist nodes.

**FR-2 — Redact PII before any LLM sees the email body.** Use Amazon Comprehend's `detect_pii_entities` on the way in. The LLM (Claude on Bedrock) must NEVER see the raw PAN, Aadhaar, account number, mobile, or IFSC. Replace each detection with `[<ENTITY_TYPE>_REDACTED]`.

**FR-3 — Build the RAG pipeline yourself, in the notebook.** No managed service this time — implement the full RAG flow:

1. Load the 10 policy PDFs from `policy_corpus/`
2. Chunk them (recursive splitter, ~800 token chunks with ~100 token overlap is a sensible default — defend in writeup if you deviate)
3. Embed chunks using **Bedrock Titan Text Embeddings v2** (`amazon.titan-embed-text-v2:0`) as the **primary** embedding model, with **OpenAI `text-embedding-3-small`** as the **fallback** after 3 failed retries on the primary
4. Index the embeddings in your **Amazon OpenSearch Service domain** (`OpenSearchVectorSearch` from `langchain_community.vectorstores`) as the **primary** vector store, with **ChromaDB persistent** as the **fallback** if OpenSearch fails to initialise after 3 retries
5. At triage time: embed the (redacted) email → retrieve top-5 chunks → pass them to the LLM with explicit citation requirements

For `loan`, `account`, and `info` categories the drafted reply must cite specific policy documents (doc_id + section). For `fraud`, `complaint`, and `unsupported` the reply still goes through retrieval but the citation requirement is softer.

**FR-4 — Re-check the draft for PII** with a Bedrock Guardrail attached to the LLM call. The Guardrail must include the four built-in PII types AND custom regex for: PAN, Aadhaar, IFSC, Indian mobile (the patterns are in `policy_corpus/indus_pii_regex.md`).

**FR-4a — LLM with retry + fallback.** Generation must use **Claude Sonnet 4.6 on Bedrock** (`ChatBedrock`) as the **primary**, with **Claude Sonnet 4.6 via direct Anthropic API** (`ChatAnthropic`) as the **fallback** after 3 failed retries on the primary. Wire this with LangChain's `.with_retry(stop_after_attempt=3, wait_exponential_jitter=True)` chained into `.with_fallbacks([...])`. The fallback chain must be the SAME `Runnable` object used everywhere the agent calls the LLM (classifier + drafter + any evaluator). Don't instantiate two separate clients in two places.

**FR-5 — Decide handoff** based on these rules (you may extend, but you must justify any extension in the write-up):

| Condition | Handoff |
|---|---|
| Output PII check = BLOCK | HUMAN_REVIEW |
| Category in {`fraud`, `complaint`} | HUMAN_REVIEW |
| Confidence < 0.6 | HUMAN_REVIEW |
| Otherwise | READY_TO_SEND |

**FR-6 — Audit trail.** Every node your graph executes must append a one-line entry to `reasoning_log`. Bank auditors will read this; write it for them.

## 5. Non-functional requirements

**NFR-1 — Use AWS services already covered in Modules 1-6.** The expected service set:

| Service | Purpose | Module covered |
|---|---|---|
| `boto3 bedrock-runtime` (`ChatBedrock`) | LLM (Sonnet 4.6) — primary path | M1 Lab 1.1 · M6 Lab 6.1 |
| `boto3 bedrock-runtime` (`BedrockEmbeddings`) | Titan v2 embeddings — primary | M4 Lab 4.2 · M6 Lab 6.1 |
| `boto3 bedrock-runtime` (`apply_guardrail`) | Output PII check | M6 Lab 6.2 |
| Amazon OpenSearch Service (domain, classic) | Vector store — primary; via `OpenSearchVectorSearch` + `opensearch-py` | M6 Lab 6.1 |
| `boto3 comprehend` (`detect_pii_entities`) | Input PII redaction | M6 Lab 6.3 |
| `boto3 textract` (`analyze_document`) | Stretch S-1 — attachment OCR | M6 Lab 6.3 |
| `boto3 ce` (Cost Explorer) | Stretch S-2 — cost report | M6 Lab 6.1 |
| Amazon S3 | Policy corpus storage (read-only) | implicit |

**Non-AWS fallbacks (required, not optional):**

| Fallback | When to fall back |
|---|---|
| OpenAI `text-embedding-3-small` (via `OpenAIEmbeddings`) | After 3 retries on Bedrock Titan v2 |
| ChromaDB persistent (`langchain_chroma.Chroma`) | If OpenSearch domain init fails after 3 retries |
| Claude Sonnet 4.6 via direct Anthropic API (`ChatAnthropic`) | After 3 retries on Bedrock Sonnet 4.6 |

**NFR-2 — Infrastructure is provided by L&D.** Your trainer-issued AWS account already has Bedrock model access enabled, an OpenSearch Service domain provisioned for you, an IAM user with the necessary permissions, and a Bedrock Guardrail pre-created. You do NOT need to create any of these — see §8 for the env-var values you'll be given.

**NFR-3 — All `!pip install` cells commented out by default** — your trainer's venv has the packages.

**NFR-4 — No hardcoded secrets** anywhere. Read every AWS / API config value from environment variables loaded via `dotenv`.

**NFR-5 — LangGraph state must be a `TypedDict`** (per M7 Lab 7.1). Use `add_messages` reducer if you append to message lists across nodes.

**NFR-6 — Fallback chains must be wired with `.with_retry()` + `.with_fallbacks()`** (LangChain v1 patterns from M3 Lab 3.1). No hand-rolled try/except per call site for the LLM and embeddings — use the Runnable wrappers so the fallback applies uniformly across every invocation.

## 6. Architecture (suggested)

```
ONE-TIME (notebook startup, idempotent):

  policy_corpus/*.pdf
        │
        ▼
  RecursiveCharacterTextSplitter (~800 tok / 100 overlap)
        │
        ▼
  ┌──────────── EMBEDDINGS ────────────┐
  │  Bedrock Titan v2  (primary)        │  ← retry × 3 → fallback
  │  OpenAI text-embedding-3-small      │
  └─────────────────┬───────────────────┘
                    ▼
  ┌──────────── VECTOR STORE ──────────┐
  │  OpenSearch domain  (primary)      │  ← init retry × 3 → fallback
  │  ChromaDB persistent               │
  └─────────────────────────────────────┘
                    ▲
                    │ (top-k retrieval)
                    │
                    │
PER EMAIL (LangGraph):

  inbound email ───┬─ (text body) ──→ Comprehend.detect_pii ──┐
                   └─ (attachments,  ──→ Textract ──┐          │
                      stretch only)                 │          │
                                       same redactor ─────────┘
                                                                 │
                                                                 ▼
                                                       ┌──── classify ────┐
                                                       │ loan/account/    │
                                                       │ fraud/complaint/ │
                                                       │ info/unsupp.     │
                                                       └──────────┬───────┘
                                                                  ▼
                                              embed query → retrieve top-5 chunks
                                                                  │
                                                                  ▼
                                              ┌──────── DRAFTER (LLM) ────────┐
                                              │  ChatBedrock Sonnet 4.6       │ ← retry × 3 → fallback
                                              │  ChatAnthropic Sonnet 4.6     │
                                              │  prompt = template(category)  │
                                              │            + retrieved chunks │
                                              │            + redacted email   │
                                              └──────────────────┬─────────────┘
                                                                 ▼
                                                          drafted reply
                                                                 │
                                                                 ▼
                                                       Bedrock Guardrail
                                                    (PAN / Aadhaar / IFSC / account#)
                                                                 │
                                                       ┌─────────┴─────────┐
                                                       ▼                   ▼
                                                  PASS + low-risk     BLOCK or fraud/complaint
                                                       │                   │
                                                       ▼                   ▼
                                                READY_TO_SEND         HUMAN_REVIEW queue
                                                                      (interrupt_before)
```

Notice: the vector store is built **once** at notebook startup (or reloaded from a persisted ChromaDB / from the OpenSearch index that already exists). Per-email work is just embed-the-question + retrieve + generate. Don't re-index per email.

## 7. Provided materials (everything you need is in this folder)

```
Capstone bundle (extract from IndusFirst_Capstone.zip)
├── Capstone_Problem_Statement.md          ← this file (the assignment brief)
├── Capstone_Starter.ipynb                 ← starter notebook with TODOs
├── emails/
│   ├── emails.jsonl                       ← 20 synthetic Indus First customer emails
│   ├── README.md                          ← email schema + label key
│   └── attachments/
│       └── salary_slips_apr_2024.pdf      ← attachment for EM-020 (used by Stretch S-1)
├── policy_corpus/                         ← chunk + embed + index these in your notebook
│   ├── pl_underwriting_policy_2024.pdf    (10 PDFs total — the bank's policy intranet)
│   ├── pl_repayment_policy_2024.pdf
│   ├── account_kyc_policy_2024.pdf
│   ├── account_closure_policy_2024.pdf
│   ├── fraud_response_protocol_2024.pdf
│   ├── card_dispute_policy_2024.pdf
│   ├── complaint_handling_2024.pdf
│   ├── branch_services_directory_2024.pdf
│   ├── tariff_schedule_2024.pdf
│   ├── interest_rate_card_2024.pdf
│   └── indus_pii_regex.md                 ← the 4 custom-PII regex patterns (developer spec)
```

L&D has provisioned your AWS account, IAM user, OpenSearch Service domain, Bedrock Guardrail, and API keys — see §8 below for the env-var values you'll be given. You don't set anything up on the AWS console.

You'll get your scored grading sheet back at the end of the take-home.

## 8. AWS services + what L&D provides

Indus First's L&D team has provisioned the AWS infrastructure for you. **You do not need to create any AWS resources yourself.** You will be given a set of values to drop into your `.env` file and start coding.

### 8.1 What L&D provides (you don't set this up)

| Provided | What it is | Where it shows up in your code |
|---|---|---|
| **AWS account access** | An IAM user with the necessary permissions for the services below — Bedrock, OpenSearch, Comprehend, Textract, S3, Cost Explorer | `aws configure` profile / `AWS_REGION` env var |
| **Bedrock model access** | Pre-enabled in your account region for: Claude Sonnet 4.6, Titan Text Embeddings v2 | `BEDROCK_LLM_MODEL_ID`, `BEDROCK_EMBEDDING_MODEL_ID` |
| **OpenSearch Service domain** | A small classic Service domain (FGAC-enabled, master user already mapped to your IAM ARN) | `OPENSEARCH_ENDPOINT`, `OPENSEARCH_INDEX_NAME` |
| **Bedrock Guardrail** | Pre-created with built-in PII (EMAIL/PHONE/NAME/CREDIT_DEBIT_CARD) + custom regex (PAN, Aadhaar, IFSC, Indian mobile) — all set to BLOCK on output | `INDUS_GUARDRAIL_ID`, `INDUS_GUARDRAIL_VERSION` |
| **S3 bucket** | Read-only access to a bucket containing the same `policy_corpus/` PDFs (or you can use the local files in this folder — your call) | `S3_POLICY_BUCKET` (optional) |
| **Anthropic API key** | For the LLM fallback path | `ANTHROPIC_API_KEY` |
| **OpenAI API key** | For the embeddings fallback path | `OPENAI_API_KEY` |

### 8.2 AWS services your agent calls directly

These are the AWS APIs your code invokes — no console clicks needed since L&D has provisioned everything:

- **Amazon Bedrock Runtime** — `ChatBedrock` (Sonnet 4.6) for classification + drafting; `BedrockEmbeddings` (Titan v2) for chunk + query embeddings; `apply_guardrail` for output PII check
- **Amazon OpenSearch Service** — direct index ops via `opensearch-py` + `OpenSearchVectorSearch` (chunks → embeddings → documents → similarity search)
- **Amazon Comprehend** — `detect_pii_entities` for input redaction
- **Amazon Textract** — `analyze_document` for the stretch goal (attachment OCR)
- **Amazon S3** — `GetObject` / `ListBucket` if you choose to read the corpus from S3 instead of locally

### 8.3 `.env` template

Create a `.env` file at your project root and fill in the values L&D will give you:

```bash
# === AWS region (L&D will tell you which) ===
AWS_REGION=us-east-1

# === Bedrock LLM (primary) — Sonnet 4.6 ===
BEDROCK_LLM_MODEL_ID=anthropic.claude-sonnet-4-6-<DATED>-v1:0

# === Bedrock Embeddings (primary) — Titan v2 ===
BEDROCK_EMBEDDING_MODEL_ID=amazon.titan-embed-text-v2:0

# === OpenSearch Service (primary vector store) ===
OPENSEARCH_ENDPOINT=<your-domain>.us-east-1.es.amazonaws.com
OPENSEARCH_INDEX_NAME=indus_capstone

# === Bedrock Guardrail ===
INDUS_GUARDRAIL_ID=<L&D-provided>
INDUS_GUARDRAIL_VERSION=DRAFT

# === Anthropic direct (LLM fallback) — same model, different channel ===
ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_LLM_MODEL_ID=claude-sonnet-4-6-<DATED>

# === OpenAI (embeddings fallback) ===
OPENAI_API_KEY=sk-...
OPENAI_EMBEDDING_MODEL_ID=text-embedding-3-small

# === S3 (optional — only if reading corpus from S3 not locally) ===
S3_POLICY_BUCKET=indus-first-policies
```

**Don't commit `.env` to git.** Add `.env` to your `.gitignore` if you're working in a fresh folder.

### 8.4 What to do if your OpenSearch domain is broken

Your starter notebook already wires the **fallback to ChromaDB persistent**. If the OpenSearch init fails after 3 retries, the pipeline transparently uses ChromaDB instead. Your code won't crash. Note in your writeup which path you ran on.

### 8.5 What to do if Bedrock Sonnet 4.6 is throttled or unavailable

The starter wires the **fallback to direct Anthropic API (`ChatAnthropic`)** with the same Sonnet 4.6 model. After 3 retries on Bedrock the chain transparently switches over. As long as your `ANTHROPIC_API_KEY` is valid, every LLM call still completes.

### 8.6 What to do if Bedrock Titan v2 is throttled

The starter wires the **fallback to OpenAI `text-embedding-3-small`**. After 3 retries on Titan the wrapper switches over per-call. Note that mixing embedding models within a single index will produce poor retrieval — if you're forced onto OpenAI for indexing, you must also use OpenAI for query embedding (the wrapper handles this for you).

## 9. Deliverables

Submit a single ZIP file named `<your_name>_indus_capstone.zip` containing:

1. **`Capstone_<your_name>.ipynb`** — your completed notebook. Must run end-to-end against your AWS account. Outputs from all cells should be visible (run before submission, save with outputs).
2. **`architecture.png`** (or `.pdf`) — your one-page architecture diagram. Hand-drawn-then-scanned is acceptable; clean tools (draw.io, Excalidraw) are preferred.
3. **`writeup.md`** (max 1 page, 12pt font equivalent) — answer these four questions:
   - **(a)** What handoff thresholds did you choose, and why? Be specific about confidence cutoff value.
   - **(b)** When did your retriever return the wrong chunk for an email, and what would you do to fix it? (chunk size, embedding model, re-ranking, metadata filtering — pick whatever applies)
   - **(c)** What's the highest-leverage thing you'd add if this went to production tomorrow? (Pick ONE.)
   - **(d)** If a regulator asked "how do you guarantee no customer PII reaches the LLM?" — what's your one-paragraph answer?
4. **`results.json`** — your agent's output for all 20 emails (the list of `TriageResult` records).

## 10. Stretch goals (only if you finish §1-9 with time to spare)

- **S-1: Textract for attachments.** Two emails in the test set come with PDF attachments (loan application, account statement). Wire Textract into the input redaction pipeline.
- **S-2: Cost reporting.** Use `boto3.client('ce')` to report your Bedrock + Comprehend + Textract spend over the last 24 hours; project monthly cost at 800 emails/day.
- **S-3: A/B chunk size.** Re-index the corpus with three chunk sizes — 500, 1000, 2000 tokens (overlap proportional). Re-run the 20 emails. Report which size gave the best citation correctness on the loan/account/info subset, and explain why.
- **S-4: Custom Indian-PII regex.** Add a fifth regex to your Guardrail for one entity type currently missed (suggestions: GSTIN, voter ID, PPF account number).

## 11. What you'll be graded on

| Dimension | Pass | Excellent |
|---|---|---|
| Router accuracy | ≥ 16/20 correct | ≥ 19/20 + confusion matrix in writeup |
| PII leak rate (post-Guardrail) | 0 leaks of PAN / Aadhaar / IFSC / account # / mobile | 0 + custom regex catches one extra type |
| **RAG quality** | Vector store builds successfully (OpenSearch primary OR ChromaDB fallback); top-5 retrieval returns relevant chunks for ≥ 80 % of test queries | 100 % retrieval relevance + chunk-size A/B in writeup (Stretch S-3) |
| RAG citation correctness | ≥ 80 % of loan/account/info replies cite a real, relevant doc | 100 % + section-level (not just doc-level) citations |
| **Fallback chains wired correctly** | LLM uses `.with_retry(stop_after_attempt=3) → .with_fallbacks([anthropic_direct])`; embeddings have a working fallback wrapper; vector-store init has try/except → ChromaDB fallback | Above + writeup names which path actually ran (primary vs fallback) and why |
| Handoff decisions | Trigger correctly on every Guardrail BLOCK + every fraud/complaint | Plus a defensible confidence threshold for low-confidence routing |
| Code quality | Functional Python, type hints, no notebook-in-notebook gore | Plus a clear separation of redactor / router / retriever / drafter / guardrail / handoff modules |
| Writeup | Answers all four questions, one page | Specific evidence (cell numbers, log lines) for each claim |

## 12. FAQ

**Q. Can I use the direct Anthropic API instead of Bedrock for the LLM?**
The PRIMARY path must be Bedrock (`ChatBedrock`). The direct Anthropic API (`ChatAnthropic`) is wired as the FALLBACK after 3 retries. Both must be configured. Same model on both sides — Sonnet 4.6.

**Q. Can I skip OpenSearch and just use ChromaDB?**
The PRIMARY path must be OpenSearch Service domain. ChromaDB is the FALLBACK if OpenSearch init fails. Both must be wired. If your OpenSearch domain genuinely never works (3-retry init fails) and you actually run on ChromaDB, that's expected — the fallback is there for exactly that reason. Note in your writeup which path you ran on.

**Q. Can I use a different LLM than Claude Sonnet 4.6?**
No. Sonnet 4.6 on both the primary (Bedrock) and fallback (Anthropic) channel. Don't substitute Haiku, Opus, or non-Claude models — the prompt templates and guardrail patterns are tuned for Sonnet 4.6.

**Q. Can I work in pairs?**
No. This is an individual assessment. You may discuss the architecture in general terms with peers but must write the code yourself.

**Q. What if my OpenSearch domain refuses connections / 500s / has a stale endpoint?**
Your fallback to ChromaDB (already wired in the starter) takes over after 3 retries on the OpenSearch init. The pipeline still runs end-to-end. Flag in your writeup which path actually ran.

**Q. What if Bedrock Sonnet 4.6 or Titan v2 is throttled when I run the 20-email loop?**
Same answer — your `.with_retry().with_fallbacks()` chain handles it. Anthropic-direct (LLM) and OpenAI (embeddings) take over per call. Your `INDUS_GUARDRAIL_ID` is Bedrock-only though, so a totally-down Bedrock means the Guardrail call fails. In that case, log the failure in `reasoning_log` and route the email to `HUMAN_REVIEW` with reason `guardrail_unavailable`.

**Q. What if Comprehend doesn't catch some PII type?**
That's expected — Comprehend's built-in detector is US-centric. You will need to layer regex on top inside your redactor. The patterns are in `policy_corpus/indus_pii_regex.md`.

**Q. What if my Bedrock Guardrail keeps blocking valid replies?**
Tune it. Use the AWS console to test individual prompts. Document the false-positive rate in your writeup; that's evidence of engineering maturity, not a failure.

**Q. Is the "human review queue" a real queue (SQS/DynamoDB)?**
No. For this assignment, output a plain Python list of records flagged HUMAN_REVIEW. The "queue" is conceptual.

**Q. Can I use Anthropic's prompt caching (M2 Lab 2.5)?**
Yes — bonus points for caching the system prompt + the policy-corpus context across the 20-email loop.

---

## Final note

This assignment is the most realistic project in the entire program. It mirrors what you will be asked to build in the first 4 weeks of any banking client engagement. Grading is strict on the things that matter to a real client (PII leak rate = 0, citations are real, audit trail is readable) and lenient on the things that don't (perfect router accuracy, beautiful UI).

If you finish the baseline by Day 3, do the stretch goals on Day 4. If you don't finish the baseline, submit what you have with an honest writeup of what's missing and why. **A well-defended partial solution beats a hand-wavy complete one.**

Good luck. — Prashant
