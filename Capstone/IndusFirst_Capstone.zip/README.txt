INDUS FIRST BANK — CUSTOMER EMAIL TRIAGE AGENT
Take-Home Capstone for eClerx GenAI Engineer Training, Cohort 1
Bundled on: 2026-05-06

================================================================
START HERE
================================================================

1. Read Capstone_Problem_Statement.md from start to finish (~15 min)
2. Confirm you have the .env values from L&D (region, OpenSearch endpoint,
   Guardrail ID, model IDs, Anthropic + OpenAI API keys — see §8.3)
3. Open Capstone_Starter.ipynb and follow §0 Setup
4. Work through TODO 1 to TODO 10 in the starter notebook

You have 4 days. Total effort: ~18-25 hours.

================================================================
WHAT'S IN THIS ZIP
================================================================

Capstone_Problem_Statement.md   The assignment brief — read first
Capstone_Starter.ipynb          Starter notebook with 10 TODOs

emails/
  README.md                     Email-set schema + label key
  emails.jsonl                  20 synthetic customer emails
  attachments/
    salary_slips_apr_2024.pdf   PDF attachment for EM-020 (Stretch S-1)

policy_corpus/                  Bank policy documents (10 PDFs)
                                — chunk + embed + index in your notebook
                                  (Bedrock Titan v2 → OpenAI fallback;
                                   OpenSearch domain → ChromaDB fallback)
  indus_pii_regex.md            4 mandatory PII regex patterns
                                + 4 optional (Stretch S-4) — developer spec

NOTE: No AWS setup files are included. L&D provides your IAM user,
OpenSearch Service domain, Bedrock Guardrail, and API keys. See
Capstone_Problem_Statement.md §8 for the .env template you'll fill in
with the values L&D hands you.

================================================================
SUBMITTING
================================================================

When you're done, ZIP your work as:
  <your_name>_indus_capstone.zip

Containing:
  - Capstone_<your_name>.ipynb     Your completed notebook (run end-to-end, save with outputs)
  - architecture.png (or .pdf)     Your one-page architecture diagram
  - writeup.md                     Your 1-page write-up (4 questions in Problem Statement §9)
  - results.json                   Your agent's TriageResult outputs for all 20 emails

Submit via Slack / email / Drive by start of Day 9 (after the 4-day break).

================================================================
QUESTIONS?
================================================================

Slack channel: #genai-cohort-1-capstone
Don't be afraid to ask. Ask early, ask specific.

— Prashant
