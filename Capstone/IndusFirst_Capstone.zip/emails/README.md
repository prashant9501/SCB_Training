# Test Email Set — schema and label key

20 synthetic Indus First Bank customer emails for the take-home assignment. All identifiers, names, account numbers, PANs, and Aadhaars are SYNTHETIC. Any resemblance to real customers is coincidental — patterns conform to the format only, not real records.

## Schema (per row in `emails.jsonl`)

| Field | Type | Notes |
|---|---|---|
| `email_id` | str | Stable identifier — use this in your `TriageResult.email_id` |
| `subject` | str | Email subject line |
| `from` | str | Customer email address (synthetic) |
| `received_at` | ISO 8601 datetime | When the email arrived |
| `body` | str | Email body text (the agent's primary input) |
| `ground_truth_category` | str | The correct category — used by the rubric to grade your router |
| `expected_pii` | list[str] | The PII entity types your redactor MUST catch in this email |
| `expected_handoff` | str | The correct handoff decision — used by the rubric |
| `attachment` | str \| null | Filename of an attached PDF (only set on EM-020 in this set; rest are pure-text emails) |

## Category distribution

| Category | Count | Email IDs |
|---|---|---|
| loan | 5 | EM-001, EM-009, EM-012, EM-013, EM-020 |
| account | 4 | EM-003, EM-006, EM-007, EM-008 |
| fraud | 3 | EM-002, EM-011, EM-015 |
| complaint | 3 | EM-004, EM-016, EM-018 |
| info | 4 | EM-005, EM-010, EM-014, EM-017 |
| unsupported | 1 | EM-019 |
| **Total** | **20** |  |

## Expected PII counts

The combined PII detection (Comprehend + Indian regex) MUST catch all entities listed in `expected_pii` for each email. Specifically:

- 6 emails contain PAN
- 4 emails contain Aadhaar
- 7 emails contain Indian mobile
- 6 emails contain Indus First account number
- 1 email contains IFSC

The `expected_pii` field reflects the union of these entity TYPES; specific span detection is on you.

## Expected handoff distribution

- READY_TO_SEND: 12 emails
- HUMAN_REVIEW: 8 emails (3 fraud + 3 complaint + 1 unsupported + 1 currently-no-other-trigger)

Note: in the rubric, your handoff thresholds (especially the confidence cutoff) are part of your design choice and you must defend them in the writeup. The 12/8 split reflects ONE reasonable answer using the default §FR-5 rules from the brief — your numbers may differ if you pick a different confidence cutoff. That's fine; defend it.

## Attachment handling

EM-020 carries `attachment: "salary_slips_apr_2024.pdf"`. This file is NOT shipped — for the stretch goal (S-1 Textract), generate or fetch any synthetic 1-page payslip-shaped PDF and put it in the `attachments/` folder. The starter notebook includes a helper to generate one via `reportlab` if you don't want to source one.

## Loading the set

```python
import json
from pathlib import Path

emails = [json.loads(line) for line in Path("emails/emails.jsonl").read_text(encoding="utf-8").splitlines()]
print(f"Loaded {len(emails)} emails")
```

## A note on grading

The `ground_truth_category` and `expected_handoff` fields are visible to you so you can self-grade as you build. The instructor uses the SAME labels for grading — there are no hidden test emails. **The rubric tests your code, not your knowledge of the labels.** Don't game the labels (e.g., by hand-coding `if email_id == "EM-002": return "fraud"`); the instructor reads the code.
