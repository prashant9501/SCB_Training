# Indian PII Patterns for Bedrock Guardrail (Custom Regex)

**Document ID:** PII-REGEX-2024
**Owner:** Information Security + Compliance
**Effective:** 2024-04-01

---

## 1. Why this document

Amazon Comprehend's `detect_pii_entities` and Bedrock Guardrails' built-in PII detector are US-centric — they cover SSN, US phone, US driver's licence, etc. Indian banking PII (PAN, Aadhaar, IFSC, mobile in Indian format) is NOT covered out of the box.

Both the input redactor (Comprehend) and the output guardrail (Bedrock Guardrail) MUST layer the regex below on top of the built-in detection.

## 2. The four mandatory patterns

| Entity | Regex pattern | Action on match |
|---|---|---|
| **PAN** (Permanent Account Number) | `\b[A-Z]{5}[0-9]{4}[A-Z]\b` | ANONYMIZE → `[PAN_REDACTED]` |
| **Aadhaar** (12-digit UID, with optional spaces every 4) | `\b\d{4}[\s-]?\d{4}[\s-]?\d{4}\b` | ANONYMIZE → `[AADHAAR_REDACTED]` |
| **IFSC** (4-letter bank code + 0 + 6-char branch code) | `\b[A-Z]{4}0[A-Z0-9]{6}\b` | ANONYMIZE → `[IFSC_REDACTED]` |
| **Indian mobile** (optional +91 / 0, then [6-9] then 9 digits) | `(?:(?:\+|0{0,2})91[\s-]?)?[6-9]\d{9}` | ANONYMIZE → `[MOBILE_REDACTED]` |

## 3. Account number patterns (special — bank-specific)

Indus First account numbers are 14 digits, beginning with `5010` (savings) or `5020` (current). Pattern:

| Entity | Regex pattern | Action on match |
|---|---|---|
| **Indus First account number** | `\b50[12]0\d{10}\b` | ANONYMIZE → `[ACCOUNT_REDACTED]` |

Generic 12-16 digit numbers are NOT redacted by default — false-positive rate is too high. Customers reference order numbers, transaction IDs, etc. that match. Only the bank-specific pattern is used in production.

## 4. Stretch goal — additional patterns (S-4 in the assignment)

Trainees may add ONE of these for stretch credit:

| Entity | Regex pattern | Notes |
|---|---|---|
| GSTIN | `\b\d{2}[A-Z]{5}\d{4}[A-Z]\d[A-Z0-9]{2}\b` | 15 chars; state code + PAN + entity code + check |
| Voter ID (EPIC) | `\b[A-Z]{3}\d{7}\b` | 10 chars; 3 letters + 7 digits |
| PPF account number | `\b\d{16}\b` (with context check) | High false-positive risk; needs context (e.g., near "PPF") |
| Driving licence (Indian) | `\b[A-Z]{2}[\s-]?\d{2}[\s-]?\d{4}[\s-]?\d{7}\b` | State code + RTO code + year + serial |

## 5. Where to wire these regex

### 5.1 In the Comprehend input redactor (Stage 1, before LLM)

After calling `comprehend.detect_pii_entities(...)`, run each of the §2 + §3 patterns over the same text and merge the entity spans before doing the redaction. This catches Indian-specific PII that Comprehend missed.

```python
import re
INDIAN_PII_PATTERNS = {
    "PAN":     r"\b[A-Z]{5}[0-9]{4}[A-Z]\b",
    "AADHAAR": r"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}\b",
    "IFSC":    r"\b[A-Z]{4}0[A-Z0-9]{6}\b",
    "MOBILE":  r"(?:(?:\+|0{0,2})91[\s-]?)?[6-9]\d{9}",
    "ACCOUNT": r"\b50[12]0\d{10}\b",
}
```

### 5.2 In the Bedrock Guardrail (Stage 2, output check)

In the AWS console → Guardrail → Sensitive Information Filters → Add custom regex. Enter each pattern from §2 + §3 with action `BLOCK` (the Guardrail blocks the entire reply if any match — stricter than the input redactor which anonymises).

The Guardrail acts as the second line of defence. The input redactor's job is to keep PII out of the LLM. The Guardrail's job is to catch anything the LLM might have hallucinated or echoed.

## 6. False positives to be aware of

- **PAN regex** — also matches some Indian vehicle registration numbers in old format (`AB12CD3456E`-style). False-positive rate is low (< 0.5 % in our internal benchmarking) but not zero.
- **Aadhaar regex** — matches any 12-digit number with the spacing pattern. Customer order numbers, reference numbers, and timestamps in `YYYYMMDD-NNNN-NNNN` format may match. Acceptable trade-off; the redactor errs on the side of safety.
- **Mobile regex** — matches Indian mobile only. International numbers in other formats may get through; trainees may extend if relevant to their use case.

## 7. Testing the patterns

Trainees should write unit tests that confirm each pattern matches AT LEAST ONE example in the test email set and DOES NOT match on a curated set of "lookalike" non-PII strings. The starter notebook includes a stub for this.
